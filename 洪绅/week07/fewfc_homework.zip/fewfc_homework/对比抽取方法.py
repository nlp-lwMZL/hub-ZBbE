"""从各方法的逐句预测重新计算 F1。运行 python 对比抽取方法.py 即可查看作业结果。"""
import json
from common.event_data import OUT, rows
from common.evaluate_events import score

# 前两列是方法和配置。不同解码器、提示词和 API 均列在所属方法下。
METHODS = [
    ("规则抽取", "词典与正则", "词典与正则"),
    ("BiLSTM-CRF", "字符级", "BiLSTM_CRF"),
    ("BERT 抽取", "RoBERTa + Linear", "RoBERTa_Linear"),
    ("BERT 抽取", "RoBERTa + CRF", "RoBERTa_CRF"),
    ("BERT 抽取", "RoBERTa 流水线", "RoBERTa_流水线"),
    ("大模型提示抽取", "Qwen 零样本", "Qwen_零样本"),
    ("大模型提示抽取", "Qwen 两示例", "Qwen_少样本"),
    ("LoRA 微调", "Qwen LoRA", "Qwen_LoRA"),
]


def compare():
    test = rows("test")
    methods = list(METHODS)
    for label in ["零样本", "少样本"]:
        if (OUT / f"Gemini_{label}.pred.jsonl").exists():
            methods.append(("大模型提示抽取", "Gemini " + label, "Gemini_" + label))

    print(f"FewFC 测试集：{len(test)} 句")
    print("| 方法 | 配置 | 触发词 F1 | 论元 F1 | 完整事件 F1 |")
    print("|---|---|---:|---:|---:|")
    for method, variant, name in methods:
        path = OUT / f"{name}.pred.jsonl"
        if not path.exists():
            print(f"| {method} | {variant} | 尚未运行 | — | — |")
            continue
        records = [json.loads(line) for line in path.read_text().splitlines()]
        by_id = {r["id"]: r for r in records}
        # 先按原句 ID 对齐并核对文本，避免重复、漏句或混入另一版测试集。
        if len(records) != len(test) or any(
            by_id.get(r["id"], {}).get("text") != r["text"] for r in test
        ):
            raise ValueError(f"{path.name} 与当前测试集不匹配，请重新运行该方法")
        report = score(test, [by_id[r["id"]]["prediction"] for r in test])
        values = [f"{report[k]['f1']:.2%}" for k in ("trigger", "argument", "event_exact")]
        print("| " + " | ".join([method, variant, *values]) + " |")


if __name__ == "__main__":
    compare()
