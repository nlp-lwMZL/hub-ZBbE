"""字符级 BiLSTM-CRF，从零训练 6 轮。"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.models import train_joint

if __name__ == "__main__":
    # 字向量和双向 LSTM 一起从头学习，CRF 负责整句解码。
    train_joint("lstm", "crf", 6)
