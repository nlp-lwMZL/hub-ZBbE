"""Qwen2.5 在本机生成，LoRA 评测时在同一个基座上加载适配器。"""

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from common.model_paths import llm_path


def load():
    device = (
        "mps"
        if torch.backends.mps.is_available()
        else "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )
    path = llm_path()
    tok = AutoTokenizer.from_pretrained(path, padding_side="left")
    # eager 显式展开分组查询注意力，避免本机 MPS 融合算子的维度问题。
    model = AutoModelForCausalLM.from_pretrained(
        path,
        attn_implementation="eager",
        torch_dtype=torch.float32 if device == "cpu" else torch.float16,
    )
    return tok, model.to(device)


@torch.inference_mode()
def generate(tok, model, chats):
    prompts = [
        tok.apply_chat_template(c, tokenize=False, add_generation_prompt=True)
        for c in chats
    ]
    batch = tok(prompts, padding=True, return_tensors="pt").to(model.device)
    ids = model.generate(
        **batch, max_new_tokens=170, do_sample=False, pad_token_id=tok.pad_token_id
    )
    # generate 返回提示词和续写两部分，只将续写交给 JSON 解析器。
    return tok.batch_decode(
        ids[:, batch.input_ids.shape[1] :], skip_special_tokens=True
    )
