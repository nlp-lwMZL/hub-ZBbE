"""Zero/few-shot 金融事件抽取。默认用本地模型，也可调用 Gemini 原生 API。"""

import argparse
import json
import os
import sys
from pathlib import Path
from urllib.request import Request, urlopen

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.event_data import rows
from common.evaluate_events import evaluate
from 大模型提示抽取.构造与解析提示 import messages, parse


def gemini(chat):
    key, model = os.environ["GEMINI_API_KEY"], os.environ["GEMINI_MODEL"]
    # Gemini 单独接收系统提示，少样本对话中的 assistant 在该接口叫 model。
    contents = [
        {
            "role": "model" if m["role"] == "assistant" else "user",
            "parts": [{"text": m["content"]}],
        }
        for m in chat[1:]
    ]
    body = {
        "system_instruction": {"parts": [{"text": chat[0]["content"]}]},
        "contents": contents,
        "generationConfig": {"temperature": 0, "responseMimeType": "application/json"},
    }
    req = Request(
        f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
        data=json.dumps(body).encode(),
        headers={"x-goog-api-key": key, "Content-Type": "application/json"},
    )
    with urlopen(req, timeout=90) as response:
        candidate = json.load(response)["candidates"][0]
    return "".join(
        p.get("text", "") for p in candidate["content"]["parts"] if not p.get("thought")
    )


def run(mode="zero", backend="local", adapter=None):
    train, test = rows("train"), rows("test")
    chats = [messages(r["text"], train, mode == "few") for r in test]
    if backend == "gemini":
        raw = [gemini(chat) for chat in chats]
    else:
        from 大模型提示抽取.Qwen本地生成 import load, generate

        tok, model = load()
        if adapter:
            from peft import PeftModel

            model = PeftModel.from_pretrained(model, adapter)
        model.eval()
        raw = []
        for i in range(len(chats)):
            raw.extend(generate(tok, model, [chats[i]]))
    provider = "Qwen" if backend == "local" else "Gemini"
    variant = "零样本" if mode == "zero" else "少样本"
    name = "Qwen_LoRA" if adapter else f"{provider}_{variant}"
    # 解析失败的输出记为空预测，仍计入评测分母。
    predictions = [parse(answer, row["text"]) for answer, row in zip(raw, test)]
    evaluate(name, test, predictions)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["zero", "few"], default="zero")
    parser.add_argument("--backend", choices=["local", "gemini"], default="local")
    args = parser.parse_args()
    run(args.mode, args.backend)
