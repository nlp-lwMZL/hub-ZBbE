"""将角色标注转换为模型需要生成的紧凑 JSON。"""

import json


def target(row):
    # 目标答案保留原文片段，字符位置在生成后再对齐。
    result = {"类型": row["type"], "触发词": "", "论元": []}
    for start, end, role in row["spans"]:
        word = row["text"][start:end]
        if role == "trigger":
            result["触发词"] = word
        else:
            result["论元"].append([role, word])
    return json.dumps(result, ensure_ascii=False, separators=(",", ":"))
