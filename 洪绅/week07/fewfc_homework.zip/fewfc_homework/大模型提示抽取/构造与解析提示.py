"""零样本与少样本共用输出格式，示例仅选自训练集。"""

import json
from common.event_data import TYPES
from 大模型提示抽取.构造事件答案 import target


def messages(text, train, few=False):
    roles = {
        t: sorted(
            {
                r
                for x in train
                if x["type"] == t
                for _, _, r in x["spans"]
                if r != "trigger"
            }
        )
        for t in TYPES
    }
    system = (
        "抽取一个金融事件。仅输出JSON对象，字段为“类型”、“触发词”、“论元”。"
        "论元是[角色,原文片段]的数组，触发词也必须来自原文。可选类型及角色："
        + json.dumps(roles, ensure_ascii=False)
    )
    chat = [{"role": "system", "content": system}]
    if few:
        for typ in TYPES:
            demo = next(x for x in train if x["type"] == typ)
            chat.extend(
                [
                    {"role": "user", "content": demo["text"]},
                    {"role": "assistant", "content": target(demo)},
                ]
            )
    return chat + [{"role": "user", "content": text}]


def parse(raw, text):
    try:
        obj, _ = json.JSONDecoder().raw_decode(raw[raw.index("{") :])
        if obj["类型"] not in TYPES or not isinstance(obj["论元"], list):
            return None
        # 有些模型把单个触发词放进数组，或用两个字段描述论元。
        # 仅统一外层格式，不翻译模型预测的角色，也不猜测多个触发词中的正确答案。
        trigger = obj["触发词"]
        if isinstance(trigger, list) and len(trigger) == 1:
            trigger = trigger[0]
        mentions = [("trigger", trigger)]
        for item in obj["论元"]:
            if isinstance(item, dict):
                item = [item["role"], item["原文片段"]]
            if not isinstance(item, list) or len(item) != 2:
                return None
            mentions.append(item)
        spans = []
        for role, word in mentions:
            if not isinstance(role, str) or not isinstance(word, str) or not word:
                return None
            # 模型给出原文片段，按首次出现位置对齐；同词多次出现时可能对错位置。
            start = text.find(word)
            if start >= 0:
                spans.append([start, start + len(word), role])
            elif role == "trigger":
                return None
        return {"type": obj["类型"], "spans": spans}
    except (ValueError, KeyError, TypeError):
        return None
