"""三个阶段：目标事件检测、质押/减持分类、按类型选择 BIO 标注头。"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import torch
from torch import nn
from common.event_data import TYPES, rows
from common.models import Features, fit_head
from common.evaluate_events import evaluate


def classifier(features, labels):
    x = torch.stack([f.mean(0) for f in features])
    y = torch.tensor(labels)
    head = nn.Linear(x.shape[1], 2)
    optimizer = torch.optim.AdamW(head.parameters(), lr=0.01)
    for _ in range(40):
        optimizer.zero_grad()
        nn.functional.cross_entropy(head(x), y).backward()
        optimizer.step()
    return head.eval()


def run():
    torch.manual_seed(42)
    torch.set_num_threads(2)
    train = rows("train", negatives=True)
    test = rows("test", negatives=True)
    encoder = Features("bert", train)
    features = encoder.encode([r["text"] for r in train])
    positives = [i for i, r in enumerate(train) if r["type"] in TYPES]
    detector = classifier(features, [int(r["type"] in TYPES) for r in train])
    typer = classifier(
        [features[i] for i in positives],
        [TYPES.index(train[i]["type"]) for i in positives],
    )
    experts = {}
    # 每个类型的专家只看该类正例，推理时由类型分类器决定调用哪一个。
    for t in TYPES:
        idx = [i for i in positives if train[i]["type"] == t]
        experts[t] = fit_head(
            "bert",
            encoder.dim,
            [features[i] for i in idx],
            [train[i] for i in idx],
            "linear",
            6,
        )
    inputs = encoder.encode([r["text"] for r in test])
    pooled = torch.stack([x.mean(0) for x in inputs])
    detects = detector(pooled).argmax(-1).tolist()
    types = typer(pooled).argmax(-1).tolist()
    gold_detection = [int(r["type"] in TYPES) for r in test]
    print(
        "检测正确句数",
        sum(p == g for p, g in zip(detects, gold_detection)),
        "/",
        len(test),
    )
    preds = []
    for i, r in enumerate(test):
        if r["type"] in TYPES:
            preds.append(
                experts[TYPES[types[i]]].predict([inputs[i]])[0] if detects[i] else None
            )
    evaluate("RoBERTa_流水线", rows("test"), preds)


if __name__ == "__main__":
    run()
