"""冻结中文 RoBERTa 的前两层，训练 Linear 或 CRF 联合标注头。"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.models import train_joint

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--decoder", choices=["linear", "crf"], default="linear")
    args = parser.parse_args()
    # 两个解码头使用同一批句子和同一编码器，便于比较。
    train_joint("bert", args.decoder, 4)
