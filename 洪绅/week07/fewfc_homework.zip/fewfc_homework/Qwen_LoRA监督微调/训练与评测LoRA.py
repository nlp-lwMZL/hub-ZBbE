"""用 32 条 FewFC 样本给 Qwen2.5 做短轮 LoRA SFT，只对答案计算损失。"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import torch
from peft import LoraConfig, get_peft_model
from common.event_data import rows, TYPES
from common.event_data import OUT
from 大模型提示抽取.零样本与少样本抽取 import run

ADAPTER = OUT / "Qwen_LoRA适配器"
from 大模型提示抽取.构造事件答案 import target
from 大模型提示抽取.构造与解析提示 import messages
from 大模型提示抽取.Qwen本地生成 import load


def train():
    torch.manual_seed(42)
    tok, model = load()
    model = get_peft_model(
        model,
        LoraConfig(
            task_type="CAUSAL_LM",
            r=4,
            lora_alpha=8,
            target_modules=["q_proj", "v_proj"],
        ),
    )
    model.train()
    optimizer = torch.optim.AdamW(
        (p for p in model.parameters() if p.requires_grad), lr=3e-4
    )
    train_rows = rows("train")
    groups = [[r for r in train_rows if r["type"] == t][:16] for t in TYPES]
    start = time.perf_counter()
    # 每步各取一条质押和减持样本，累积两次梯度后只更新一次适配器。
    for step, pair in enumerate(zip(*groups), 1):
        optimizer.zero_grad()
        for r in pair:
            prompt = tok.apply_chat_template(
                messages(r["text"], train_rows),
                tokenize=True,
                add_generation_prompt=True,
            )
            answer = tok.encode(target(r), add_special_tokens=False) + [
                tok.eos_token_id
            ]
            ids = torch.tensor([prompt + answer], device=model.device)
            labels = ids.clone()
            # 忽略提问部分：训练目标是生成事件 JSON。
            labels[:, : len(prompt)] = -100
            loss = model(input_ids=ids, labels=labels, use_cache=False).loss
            if not torch.isfinite(loss):
                raise ValueError("训练损失异常")
            (loss / len(pair)).backward()
        optimizer.step()
        print(f"第 {step} 步，loss={loss.item():.3f}", flush=True)
    model.save_pretrained(ADAPTER)
    print(f"LoRA 训练耗时 {time.perf_counter() - start:.1f}s")


if __name__ == "__main__":
    train()
    # 同一个脚本在短训结束后直接生成测试集预测。
    run(adapter=ADAPTER)
