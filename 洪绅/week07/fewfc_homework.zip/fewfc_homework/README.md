# Week 7 作业 · 金融事件抽取

五种方法使用 FewFC 的“质押”和“减持”样本。每种方法一个目录，共用训练集、测试集和评分函数。进入本目录执行：

```bash
python 对比抽取方法.py
```

脚本用随作业保存的逐句预测，对齐相同的 16 句测试文本，输出触发词、论元和完整事件的 micro-F1。查看结果只需要 Python 标准库。

| 方法目录 | 单独运行 | 本次设置 |
|---|---|---|
| 词典与正则抽取 | `python 词典与正则抽取/词典与正则抽取.py` | 词典和数值正则 |
| BiLSTM_CRF序列标注 | `python BiLSTM_CRF序列标注/训练BiLSTM_CRF.py` | 字符级 BiLSTM-CRF，6 轮 |
| RoBERTa事件抽取 | `python RoBERTa事件抽取/训练RoBERTa联合标注.py --decoder linear`、`python RoBERTa事件抽取/训练RoBERTa联合标注.py --decoder crf`、`python RoBERTa事件抽取/训练RoBERTa流水线.py` | 中文 RoBERTa 前两层冻结，比较联合标注和分阶段抽取 |
| 大模型提示抽取 | `python 大模型提示抽取/零样本与少样本抽取.py --mode zero` 或 `--mode few` | Qwen2.5-0.5B-Instruct，零样本或两个训练示例 |
| Qwen_LoRA监督微调 | `python Qwen_LoRA监督微调/训练与评测LoRA.py` | 同一 Qwen 基座，32 条样本、16 个优化步，随后评测 |

每种方法运行后更新自己的预测文件，再执行 `python 对比抽取方法.py` 即可看到新结果。神经模型可在本机 `conda activate py312` 后运行，其他环境可按 `requirements.txt` 安装依赖。默认从本地缓存读模型，也可用 `ENCODER_PATH` 和 `LLM_PATH` 分别指定中文 RoBERTa 和 Qwen 的模型目录。先前本机实测，判别式训练脚本各约 3 秒，LoRA 训练约十几秒，生成评测另计。

提示抽取也支持 `--backend gemini`，需设置 `GEMINI_API_KEY` 和 `GEMINI_MODEL`。随作业提供的是本地 Qwen 结果，云端预测运行后会自动出现在对比表中。

数据来自 FewFC 原始基础域划分，许可见 `data/LICENSE.txt`。抽取训练每类 80 句、测试每类 8 句，另有 80 条训练负例和 8 条测试负例用于流水线检测。选取单事件、最长 96 字、片段无重叠的句子，按文本去重。论元命中要求事件类型、角色和字符位置一致，完整事件还要求触发词和全部论元均匹配。[FewFC 数据来源](https://github.com/TimeBurningFish/FewFC/tree/ec6cac90238c04b45d4512a695ee6375fc72af2f)
