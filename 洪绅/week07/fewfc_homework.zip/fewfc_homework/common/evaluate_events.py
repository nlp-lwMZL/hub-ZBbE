"""按句累计 micro-F1，触发词和论元均要求类型、角色和字符位置匹配。"""

import json
from common.event_data import OUT


def facts(event):
    if not event:
        return set(), set(), set()
    typ = event["type"]
    triggers = {(typ, a, b) for a, b, r in event["spans"] if r == "trigger"}
    args = {(typ, r, a, b) for a, b, r in event["spans"] if r != "trigger"}
    return triggers, args, {(typ, frozenset(triggers), frozenset(args))}


def score(samples, predictions):
    assert len(samples) == len(predictions)
    counts = [[0, 0, 0] for _ in range(3)]
    for row, pred in zip(samples, predictions):
        # 命中数、预测数和金标数跨句累加，避免短句和长句被赋予相同权重。
        for c, g, p in zip(counts, facts(row), facts(pred)):
            c[0] += len(g & p)
            c[1] += len(p)
            c[2] += len(g)
    report = {"n": len(samples)}
    for metric, (hit, p, g) in zip(("trigger", "argument", "event_exact"), counts):
        report[metric] = dict(
            correct=hit, predicted=p, gold=g, f1=round(2 * hit / max(1, p + g), 4)
        )
    return report


def evaluate(name, samples, predictions):
    report = score(samples, predictions)
    lines = []
    for row, pred in zip(samples, predictions):
        lines.append(
            json.dumps(
                dict(id=row["id"], text=row["text"], prediction=pred),
                ensure_ascii=False,
            )
        )
    OUT.mkdir(exist_ok=True)
    (OUT / f"{name}.pred.jsonl").write_text("\n".join(lines) + "\n")
    print(name, report)
