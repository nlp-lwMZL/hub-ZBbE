"""优先读取本地缓存，也可用环境变量指向下载好的模型目录。"""

import os
from huggingface_hub import snapshot_download


def model_path(env, repo):
    return os.environ.get(env) or snapshot_download(repo, local_files_only=True)


def encoder_path():
    return model_path("ENCODER_PATH", "hfl/chinese-roberta-wwm-ext")


def llm_path():
    return model_path("LLM_PATH", "Qwen/Qwen2.5-0.5B-Instruct")
