"""共享字符编码、联合 BIO 标注器。RoBERTa 冻结前两层的输出，作业只训练标注头。"""

import torch
from torch import nn
from torch.nn.utils.rnn import pad_sequence, pack_padded_sequence, pad_packed_sequence
from transformers import BertModel, BertTokenizer
from common.model_paths import encoder_path
from common.crf import CRF
from common.event_data import rows, labels_for, decode
from common.evaluate_events import evaluate


class Features:
    def __init__(self, kind, train):
        self.kind = kind
        # 字表只由训练文本构建，未见字符统一映射为 1。
        self.vocab = {
            c: i + 2
            for i, c in enumerate(sorted({c for r in train for c in r["text"]}))
        }
        if kind == "bert":
            path = encoder_path()
            self.tok = BertTokenizer.from_pretrained(path)
            self.encoder = BertModel.from_pretrained(
                path, num_hidden_layers=2, add_pooling_layer=False
            ).eval()
            self.dim = self.encoder.config.hidden_size
        else:
            self.dim = len(self.vocab) + 2

    @torch.no_grad()
    def encode(self, texts):
        if self.kind == "lstm":
            return [
                torch.tensor([self.vocab.get(c, 1) for c in text]) for text in texts
            ]
        features = []
        for i in range(0, len(texts), 12):
            chunk = texts[i : i + 12]
            # 每个原文字符占一个位置，数字和空格也保留，方便还原 span。
            ids = [
                torch.tensor(
                    [self.tok.cls_token_id]
                    + self.tok.convert_tokens_to_ids(list(text))
                    + [self.tok.sep_token_id]
                )
                for text in chunk
            ]
            batch = pad_sequence(
                ids, batch_first=True, padding_value=self.tok.pad_token_id
            )
            mask = (
                torch.arange(batch.shape[1])[None, :]
                < torch.tensor([len(s) for s in ids])[:, None]
            )
            hidden = self.encoder(batch, attention_mask=mask).last_hidden_state
            features.extend(
                hidden[j, 1 : 1 + len(text)].clone() for j, text in enumerate(chunk)
            )
        return features


class Tagger(nn.Module):
    def __init__(self, kind, dim, labels, decoder):
        super().__init__()
        self.labels = labels
        self.kind = kind
        if kind == "lstm":
            self.embedding = nn.Embedding(dim, 48, padding_idx=0)
            self.encoder = nn.LSTM(48, 48, bidirectional=True, batch_first=True)
            dim = 96
        self.head = nn.Linear(dim, len(labels))
        self.crf = CRF(len(labels)) if decoder == "crf" else None

    def forward(self, features):
        x = pad_sequence(features, batch_first=True)
        lengths = torch.tensor([len(s) for s in features])
        mask = torch.arange(x.shape[1])[None, :] < lengths[:, None]
        if self.kind == "lstm":
            packed = pack_padded_sequence(
                self.embedding(x), lengths, batch_first=True, enforce_sorted=False
            )
            x, _ = pad_packed_sequence(self.encoder(packed)[0], batch_first=True)
        return self.head(x), mask

    @torch.no_grad()
    def predict(self, features):
        logits, mask = self(features)
        paths = (
            self.crf.decode(logits, mask) if self.crf else logits.argmax(-1).tolist()
        )
        return [
            decode([self.labels[k] for k in path[: len(x)]])
            for path, x in zip(paths, features)
        ]


def fit_head(kind, dim, features, samples, decoder, epochs):
    tags = [labels_for(r) for r in samples]
    names = ["O"] + sorted({l for seq in tags for l in seq if l != "O"})
    ids = {name: i for i, name in enumerate(names)}
    targets = [torch.tensor([ids[l] for l in seq]) for seq in tags]
    model = Tagger(kind, dim, names, decoder)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=0.008 if kind == "lstm" else 0.003
    )
    for _ in range(epochs):
        # 每轮打乱训练句。mask 排除补齐位置，CRF 学转移分数，Linear 逐字算交叉熵。
        for idx in torch.randperm(len(features)).split(16):
            logits, mask = model([features[i] for i in idx])
            gold = pad_sequence([targets[i] for i in idx], batch_first=True)
            if model.crf:
                loss = (
                    model.crf.neg_log_likelihood(logits, gold, mask)
                    / mask.sum(1).float().mean()
                )
            else:
                loss = nn.functional.cross_entropy(logits[mask], gold[mask])
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
    return model.eval()


def train_joint(kind, decoder, epochs):
    torch.manual_seed(42)
    torch.set_num_threads(2)
    train, test = rows("train"), rows("test")
    encoder = Features(kind, train)
    x = encoder.encode([r["text"] for r in train])
    model = fit_head(kind, encoder.dim, x, train, decoder, epochs)
    name = "BiLSTM_CRF" if kind == "lstm" else "RoBERTa_" + {"linear": "Linear", "crf": "CRF"}[decoder]
    evaluate(name, test, model.predict(encoder.encode([r["text"] for r in test])))
