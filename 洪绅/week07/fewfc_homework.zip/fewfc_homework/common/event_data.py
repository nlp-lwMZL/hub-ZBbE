"""统一读写 FewFC 作业样本。span = (起点, 终点, 角色)，终点不计入。"""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
TYPES = ("减持", "质押")


def rows(split, negatives=False):
    samples = [
        json.loads(line)
        for line in (ROOT / "data" / f"{split}.jsonl").read_text().splitlines()
    ]
    return samples if negatives else [r for r in samples if r["type"] in TYPES]


def labels_for(row):
    # 触发词的标签带事件类型，论元的标签带角色，一条 BIO 序列即可表达一个事件。
    labels = ["O"] * len(row["text"])
    for start, end, role in row["spans"]:
        label = "@" + row["type"] if role == "trigger" else role
        labels[start:end] = ["B-" + label] + ["I-" + label] * (end - start - 1)
    return labels


def decode(labels, expected=None):
    # I 标签只与紧邻的同类片段合并；联合模型用第一个触发片段确定该句事件类型。
    spans = []
    for i, tag in enumerate(labels):
        if tag == "O":
            continue
        kind = tag[2:]
        if tag.startswith("I-") and spans and spans[-1][1:] == [i, kind]:
            spans[-1][1] += 1
        else:
            spans.append([i, i + 1, kind])
    triggers = [
        s
        for s in spans
        if s[2].startswith("@") and (not expected or s[2][1:] == expected)
    ]
    if not triggers:
        return None
    a, b, t = triggers[0]
    return {
        "type": t[1:],
        "spans": [[a, b, "trigger"]] + [s for s in spans if not s[2].startswith("@")],
    }
