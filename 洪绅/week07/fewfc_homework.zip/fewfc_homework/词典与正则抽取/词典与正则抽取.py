"""规则基线：从训练标注统计触发词和论元词典，用正则补充数量与比例。"""

import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.event_data import rows
from common.evaluate_events import evaluate


class Rules:
    def __init__(self, train):
        self.triggers = Counter()
        self.words = defaultdict(Counter)
        for row in train:
            for a, b, role in row["spans"]:
                word = row["text"][a:b]
                if role == "trigger":
                    self.triggers[row["type"], word] += 1
                else:
                    self.words[row["type"]][word, role] += 1

    def predict(self, text):
        # 训练集中常见的事件词优先；同一个词在句中多次出现时取第一次。
        for (typ, word), _ in self.triggers.most_common():
            a = text.find(word)
            if a >= 0:
                break
        else:
            return None
        spans = [[a, a + len(word), "trigger"]]
        occupied = set(range(a, a + len(word)))
        # 数值每句都可能变化，所以先找数字，再用词典找固定称谓等片段。
        candidates = []
        for role, pattern in [
            ("proportion", r"\d+(?:\.\d+)?[%％]"),
            ("number", r"[\d,]+(?:\.\d+)?(?:万|亿)?(?=股)"),
        ]:
            candidates.extend(
                (m.start(), m.end(), role) for m in re.finditer(pattern, text)
            )
        for (surface, role), _ in self.words[typ].most_common():
            pos = text.find(surface)
            if pos >= 0:
                candidates.append((pos, pos + len(surface), role))
        for start, end, role in candidates:
            if occupied.isdisjoint(range(start, end)):
                spans.append([start, end, role])
                occupied.update(range(start, end))
        return {"type": typ, "spans": spans}


if __name__ == "__main__":
    rules = Rules(rows("train"))
    test = rows("test")
    evaluate("词典与正则", test, [rules.predict(r["text"]) for r in test])
